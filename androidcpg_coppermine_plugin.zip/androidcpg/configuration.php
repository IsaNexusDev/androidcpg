<?php
/*This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License version 3
  as published by the Free Software Foundation.

  ********************************************
  AndroidCPG version: 1.5.30.1
**********************************************/

$name = 'AndroidCPG';
$description = 'Allows Android CPG app to connnect with this site. Alowed operations: create albums and upload files (Images and videos)';
$author = 'IsaNexusDev';
$version = '1.0';
$plugin_cpg_version = array('min' => '1.5');
$extra_info = '<a href="http://androidcpg.mine.bz/" rel="external" class="external">AndroidCPG</a>';
$install_info= '<a href="http://androidcpg.mine.bz/" rel="external" class="external">AndroidCPG</a>';
?>